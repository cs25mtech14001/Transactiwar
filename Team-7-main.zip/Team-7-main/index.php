<?php
# Atish Kadam - CS25MTECH14003
# Akarsh Dubey - CS25MTECH14001
# Atharva Kale - CS25MTECH11024
# Prashant Kumar Dubey - CS25MTECH14011
# Debdip Choudhuri - CS25MTECH11025
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

// Already logged in → go to dashboard
if (!empty($_SESSION['logged_in'])) {
    redirect(BASE_URL . '/public/dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>TransactiWar – Secure Transactions</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      background: #0f172a;
      color: #e2e8f0;
      font-family: 'Segoe UI', sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Animated background */
    body::before {
      content: '';
      position: fixed;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(ellipse at 20% 50%, rgba(99,102,241,0.15) 0%, transparent 50%),
                  radial-gradient(ellipse at 80% 20%, rgba(139,92,246,0.1) 0%, transparent 50%),
                  radial-gradient(ellipse at 60% 80%, rgba(59,130,246,0.1) 0%, transparent 50%);
      z-index: 0;
      animation: bgFloat 8s ease-in-out infinite alternate;
    }

    @keyframes bgFloat {
      0%   { transform: translate(0, 0) rotate(0deg); }
      100% { transform: translate(2%, 2%) rotate(1deg); }
    }

    .content {
      position: relative;
      z-index: 1;
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      text-align: center;
    }

    /* Logo */
    .logo-icon {
      font-size: 4rem;
      margin-bottom: 1rem;
      animation: pulse 2s ease-in-out infinite;
    }

    @keyframes pulse {
      0%, 100% { transform: scale(1); }
      50%       { transform: scale(1.08); }
    }

    .brand-name {
      font-size: 3rem;
      font-weight: 800;
      color: #ffffff;
      letter-spacing: -1px;
      margin-bottom: 0.5rem;
    }

    .brand-name span {
      background: linear-gradient(135deg, #6366f1, #8b5cf6, #06b6d4);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .tagline {
      font-size: 1.1rem;
      color: #94a3b8;
      margin-bottom: 3rem;
      max-width: 400px;
    }

    /* Buttons */
    .btn-group-landing {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
      justify-content: center;
    }

    .btn-signin {
      background: linear-gradient(135deg, #6366f1, #8b5cf6);
      border: none;
      color: #fff;
      padding: 0.85rem 2.5rem;
      font-size: 1rem;
      font-weight: 600;
      border-radius: 50px;
      text-decoration: none;
      transition: all 0.3s ease;
      box-shadow: 0 4px 20px rgba(99,102,241,0.4);
    }

    .btn-signin:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 30px rgba(99,102,241,0.6);
      color: #fff;
    }

    .btn-register {
      background: transparent;
      border: 2px solid #334155;
      color: #e2e8f0;
      padding: 0.85rem 2.5rem;
      font-size: 1rem;
      font-weight: 600;
      border-radius: 50px;
      text-decoration: none;
      transition: all 0.3s ease;
    }

    .btn-register:hover {
      border-color: #6366f1;
      color: #ffffff;
      background: rgba(99,102,241,0.1);
      transform: translateY(-3px);
    }

    /* Stats bar */
    .stats-bar {
      display: flex;
      gap: 3rem;
      margin-top: 4rem;
      flex-wrap: wrap;
      justify-content: center;
    }

    .stat-item {
      text-align: center;
    }

    .stat-value {
      font-size: 1.6rem;
      font-weight: 700;
      color: #ffffff;
    }

    .stat-label {
      font-size: 0.8rem;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .divider {
      width: 1px;
      background: #1e293b;
      height: 40px;
      align-self: center;
    }

    /* Feature pills */
    .features {
      display: flex;
      gap: 0.75rem;
      margin-top: 2.5rem;
      flex-wrap: wrap;
      justify-content: center;
    }

    .feature-pill {
      background: rgba(99,102,241,0.1);
      border: 1px solid rgba(99,102,241,0.2);
      color: #a5b4fc;
      padding: 0.4rem 1rem;
      border-radius: 50px;
      font-size: 0.82rem;
      font-weight: 500;
    }

    /* Footer */
    footer {
      position: relative;
      z-index: 1;
      text-align: center;
      padding: 1.5rem;
      color: #334155;
      font-size: 0.8rem;
    }
  </style>
</head>
<body>

  <div class="content">
    <div class="logo-icon">💸</div>

    <h1 class="brand-name">Transacti<span>War</span></h1>
    <p class="tagline">A secure financial transaction platform. Send money, track history, stay protected.</p>

    <div class="btn-group-landing">
      <a href="public/login.php" class="btn-signin">Log in</a>
      <a href="public/register.php" class="btn-register">Create Account</a>
    </div>

    </div>
  </div>

  <footer>
    &copy; 2026 TransactiWar · Team 7 · Network Security Project
  </footer>

</body>
</html>